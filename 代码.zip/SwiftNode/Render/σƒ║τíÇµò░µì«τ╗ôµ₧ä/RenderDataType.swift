//
//  RenderDataType.swift
//  SwiftNode
//
//  Created by aa on 2024/1/30.
//

import Foundation

typealias GUIFloat = Double
typealias GUIVector = GUIPoint
struct GUIPoint {
    var x,y:GUIFloat
    
    public static var zero: GUIPoint {
        return GUIPoint.init(x: 0, y: 0)
    }
    
    var cgPoint:CGPoint {
        CGPoint.init(x: self.x, y: self.y)
    }
    
}

struct GUISize {
    var w,h:GUIFloat
    
    public static var zero: GUISize {
        return GUISize.init(w: 0, h: 0)
    }
    
    var cgSize:CGSize {
        CGSize.init(width: self.w, height: self.h)
    }
    
}

struct GUIRect {
    var postion:GUIPoint
    var size:GUISize
    
    var cgRect:CGRect {
        .init(origin: self.postion.cgPoint, size: self.size.cgSize)
    }
    
    static var zero:GUIRect {
        .init(postion: .zero, size: .zero)
    }
}

//四边形
struct GUIQuadrilateral  {
    var pos = [GUIPoint].init(repeating: .zero, count: 4)
    
    init(posList:[GUIPoint]) {
//        guard posList.count == 4 else {
//            return nil
//        }
        self.pos = posList
    }
    
    init(pos1:GUIPoint,pos2:GUIPoint,pos3:GUIPoint,pos4:GUIPoint) {
        self.pos[0] = pos1
        self.pos[1] = pos2
        self.pos[2] = pos3
        self.pos[3] = pos4
    }
    
    //使用Rect的postion
    init(rect:GUIRect) {
        var pos = rect.postion
        var size = rect.size
        self.pos[0] = .init(x: pos.x, y: pos.y + size.h)
        self.pos[1] = .init(x: pos.x + size.w, y: pos.y + size.h)
        self.pos[0] = pos
        self.pos[0] = .init(x: pos.x + size.w, y: pos.y)
    }
    
    var center:GUIPoint {
        var x = (pos[3].x - pos[2].x) / 2
        var y = (pos[0].y - pos[2].y) / 2
        return .init(x: x, y: y)
    }
    
    //将四边形转化为两个三角形用于渲染
    var triangles:[GUITriangle] {
        var list = [GUITriangle].init(repeating: .zero, count: 2)
        var one = GUITriangle.init(pos1: pos[0], pos2: pos[1], pos3: pos[2])
        var two = GUITriangle.init(pos1: pos[2], pos2: pos[1], pos3: pos[3])
    }
    
}

struct GUITriangle {
    var pos = [GUIPoint].init(repeating: .zero, count: 3)
    
    init(pos1:GUIPoint,pos2:GUIPoint,pos3:GUIPoint) {
        self.pos[0] = pos1
        self.pos[1] = pos2
        self.pos[2] = pos3
    }
    
    public static var zero: GUITriangle {
        return GUITriangle(pos1: .zero, pos2: .zero, pos3: .zero)
    }
}

struct GUILine {
    private var pos = [GUIPoint].init(repeating: .zero, count: 2)
    
    var start:GUIPoint {
        set {
            pos[0] = newValue
        }
        get {
            return pos[0]
        }
    }
    
    var end:GUIPoint {
        set {
            pos[1] = newValue
        }
        get {
            return pos[1]
        }
    }
    
    init(start:GUIPoint,end:GUIPoint) {
        self.pos[0] = start
        self.pos[1] = end
    }
}



