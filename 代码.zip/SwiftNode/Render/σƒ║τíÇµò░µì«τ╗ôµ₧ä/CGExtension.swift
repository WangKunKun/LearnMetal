//
//  CGExtension.swift
//  SwiftNode
//
//  Created by aa on 2024/1/30.
//

import Foundation

extension CGPoint {
    var gPoint:GUIPoint {
        GUIPoint.init(x: self.x, y: self.y)
    }
}

extension CGSize {
    var gSize:GUISize {
        GUISize.init(w: self.width, h: self.height)
    }
}

extension CGRect {
    var gRect:GUIRect {
        GUIRect.init(postion: self.origin.gPoint, size: self.size.gSize)
    }
}
