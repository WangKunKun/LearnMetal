//
//  GUIExtension.swift
//  SwiftNode
//
//  Created by aa on 2024/1/30.
//

import Foundation

extension GUIPoint : Equatable {
    static func == (left:GUIPoint, right:GUIPoint) -> Bool {
        return left.x == right.x && left.y == right.y
    }
    
    static func + (left:GUIPoint, right:GUIPoint) -> GUIPoint {
        return GUIPoint.init(x: left.x + right.x, y: left.y + right.y)
    }
    
    static func - (left:GUIPoint, right:GUIPoint) -> GUIPoint {
        return GUIPoint.init(x: left.x - right.x, y: left.y - right.y)
    }
    
    //距离
    func distance(right:GUIPoint) -> GUIFloat {
        var left = self
        var dx = left.x - right.x
        var dy = left.y - right.y
        return sqrt((dx * dx + dy * dy))
    }
    //算中心点
    func center(end:GUIPoint) -> GUIPoint {
        var sum = self + end
        return GUIPoint.init(x: sum.x / 2, y: sum.y / 2)
    }
    //转换至子视图坐标
    func toChildCoordinates(_ childPos:GUIPoint) -> GUIPoint {
        self - childPos
    }
    //转换至父视图坐标
    func toParentCoordinates(_ parentPos:GUIPoint) -> GUIPoint {
        self + parentPos
    }
    
    //由于metal屏幕坐标系是以屏幕中心点为原点的[-1,1],所以需要转换
    func toMetalCoordinates(_ mtkViewSize:GUISize) -> GUIPoint {
        var xRatio = self.x / mtkViewSize.w
        var yRatio = self.y / mtkViewSize.h
        //metal坐标系是从中心点开始的,x往右y往上的正数；view的坐标系是以左上角开始的，x往右正，y往下正
        //x坐标是同向递增且view的x为0时，metal的x为-1，则view的x乘以2并且加上-1.0得到metal的x
        //y坐标是同向递减且view的y为0时，metal的y为1，则view的x乘以-2并且加上1得到metal的y，
        var metalX = 2.0 * xRatio - 1.0
        var metalY = -2.0 * yRatio + 1.0
        return GUIPoint.init(x: metalX, y: metalY)
    }
}
//归一化向量
typealias GUINormalVector = GUIVector
extension GUIVector {
    //使用斜边长进行归一化
    func normalization() -> GUINormalVector {
        var len = sqrtl(self.x * self.x + self.y * self.y)
        return .init(x: self.x / len, y: self.y / len)
    }
    
    func generateNormalizeationLine(len:GUIFloat, verctor:GUINormalVector) -> GUILine {
        var endX = self.x + verctor.x * len
        var endY = self.y + verctor.y * len
        return .init(start: self, end: .init(x: endX, y: endY))
    }
}

extension GUISize : Equatable {
    
    static func == (left:GUISize, right:GUISize) -> Bool {
        return left.w == right.w && left.h == right.h
    }
    
    static func + (left:GUISize, right:GUISize) -> GUISize {
        return GUISize.init(w: left.w + right.w, h: left.h + right.h)
    }
    
    static func - (left:GUISize, right:GUISize) -> GUISize {
        return GUISize.init(w: left.w - right.w, h: left.h - right.h)
    }
}

extension GUIRect {
    func contains(point:GUIPoint) -> Bool {
        return point.x >= 0 && point.x <= self.size.w && point.y >= 0 && point.y <= self.size.h
    }
}

extension GUIQuadrilateral {
    
    func toMetalCoordinates(_ mtkViewSize:GUISize) -> GUIQuadrilateral {
        
        var new = [GUIPoint].init(repeating: .zero, count: 4)
        for p in self.pos {
            new.append(p.toMetalCoordinates(mtkViewSize))
        }
        //节点数必须是4
        return GUIQuadrilateral.init(posList: new)
    }
}

extension GUILine : Equatable {
    
    static func == (left:GUILine, right:GUILine) -> Bool {
        return left.start == right.start && left.end == right.end
    }
    
    func toMetalCoordinates(_ mtkViewSize:GUISize) -> GUILine {
        var start =  self.start.toMetalCoordinates(mtkViewSize)
        var end =  self.start.toMetalCoordinates(mtkViewSize)
    }
    
    mutating func startOffset(x:GUIFloat = 0, y:GUIFloat = 0) {
        self.start.x += x
        self.start.y += y
    }
    
    mutating func endOffset(x:GUIFloat = 0, y:GUIFloat = 0) {
        self.end.x += x
        self.end.y += y
    }
}

