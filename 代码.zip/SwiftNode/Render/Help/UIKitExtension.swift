//
//  UIKitExtension.swift
//  SwiftNode
//
//  Created by aa on 2024/1/31.
//

import Foundation
import UIKit

extension UITouch : AddressDescription {}

extension Array {
    mutating func pop() -> Element? {
        return self.removeLast() //模拟栈 后进先出
    }
    
    mutating func dequeue() -> Element? {
        return self.removeFirst() //模拟队列 先进先出
    }
}
