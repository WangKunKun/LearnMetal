//
//  BaseExtension.swift
//  SwiftNode
//
//  Created by aa on 2024/1/31.
//

import Foundation

//只能Class遵守 打印地址
protocol AddressDescription : AnyObject {
    var address:String { get }
}
    
extension AddressDescription {
    var address:String {
        return "\(Unmanaged.passUnretained(self).toOpaque())"
    }
}
    


