//
//  GUIResponder.swift
//  SwiftNode
//
//  Created by aa on 2024/1/30.
//

import Foundation
import UIKit

//先不继承NSObject试试
class GUIResponder : NSObject, AddressDescription {
    
    func handleTouchesBegan(_ touch:GUITouch, event:UIEvent?){}
    func handleTouchesMoved(_ touch:GUITouch, event:UIEvent?){}
    func handleTouchesEnded(_ touch:GUITouch, event:UIEvent?){}
    func handleTouchesCancelled(_ touch:GUITouch, event:UIEvent?){}

}

