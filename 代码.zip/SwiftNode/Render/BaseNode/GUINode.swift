//
//  GUINode.swift
//  SwiftNode
//
//  Created by aa on 2024/1/30.
//

import Foundation
import UIKit

class GUINode: GUIResponder {
    
    var name = "GUINode"
    
    weak var parent:GUINode?
    weak var rootWindow:GUIWindow? {
        guard let root = _root else {
            _root = self.findRootWindow()
            return _root
        }
        return root
    }
    private weak var _root:GUIWindow?
    var children:[GUINode] = []
    var isTouchEnable = false
    
    //这里有几种情况，一种是单独只设置本身，一种是设置自子视图
    var isNeedDraw = false
    
    var isHidden = false {
        didSet {
            //这个状态我觉得需要同步给子视图，它都隐藏了
            updateNeedDraw(!isHidden)
        }
    }
    
    var frame:GUIRect {
        didSet {
            updateNeedDraw(true)
        }
    }
    
    init(with frame:GUIRect) {
        self.frame = frame
        super.init()
    }
    //我觉得都应该同步
    func updateNeedDraw(_ flag:Bool, syncToChildren:Bool = true) {
        self.isNeedDraw = flag
        if isNeedDraw && syncToChildren {
            for node in self.children {
                node.isNeedDraw = isNeedDraw
            }
        }
    }
    
}

//MARK: Draw
extension GUINode {
    func draw(rect:GUIRect, render:GUIRender) {
        
    }
}

extension GUINode {
    
    func addSubNode(_ node:GUINode) {
        self.children.append(node)
        node.parent = self
    }

    func removeForParent() {
        guard let parent = self.parent else {
            return
        }
        parent.children.removeAll { node in
            node == self
        }
        parent.isNeedDraw = true//移除了子视图，重新渲染
        self.parent = nil
    }
}

extension GUINode {
    func point(inside point: GUIPoint, with event: UIEvent?) -> Bool {
        return self.frame.contains(point: point)
    }
    
    func hitTest(_ point: GUIPoint, with event: UIEvent?) -> GUINode? {
        guard self.point(inside: point, with: event) else {
            return nil
        }
        let list = self.children.reversed()
        for child in list {
            if !child.isTouchEnable {
                continue
            }
            let childPoint = point.toChildCoordinates(child.frame.postion)
            //几乎会遍历所有的子视图的子视图 感觉效率不高，考虑如何优化
            //在树中查找某个节点，树本身希望是有结构的
            if let view = child.hitTest(childPoint, with: event) {
                return view
            }
        }
        return self
    }
}

//MARK: help
extension GUINode {
    
    private func findRootWindow() -> GUIWindow? {
        var node:GUINode? = self
        while node != nil {
            if let window = node as? GUIWindow {
                return window
            }
            node = node?.parent
        }
        return nil
    }
    
    func toWindowCoordinates(with offsetPoint:GUIPoint = .zero) -> GUIPoint {
        if self is GUIWindow {
            //默认GUIWindow起点是zero，如果有偏移需要来调整
            return .zero
        }
        var newPos = self.frame.postion + offsetPoint
        var node = self.parent
        while node != nil {
            if node is GUIWindow {
                break
            }
            newPos = newPos.toParentCoordinates(node!.frame.postion)
            node = node?.parent
        }
        guard let node = node else {
            return GUIPoint.init(x: Double.leastNormalMagnitude, y: Double.leastNormalMagnitude)
        }
        return newPos
    }
}

//不继承自NSObject才需要
//extension GUINode  {
//    override var description: String {
//        self.printInfo
//    }
//    
//    override var debugDescription: String {
//        self.printInfo
//    }
//    
//    private var printInfo:String {
//        return  "\(self.classForCoder)"
//    }
//}
