//
//  MetalDisplayView.swift
//  SwiftNode
//
//  Created by aa on 2024/1/30.
//

protocol GUIDelegate : AnyObject {
    func GUITouchBegan(_ touches: Set<UITouch>, with event: UIEvent?)
    func GUITouchMoved(_ touches: Set<UITouch>, with event: UIEvent?)
    func GUITouchEnded(_ touches: Set<UITouch>, with event: UIEvent?)
    func GUITouchCancelled(_ touches: Set<UITouch>, with event: UIEvent?)
    func GUILayoutSubViews(rect:CGRect)
}

import UIKit
import MetalKit

class MetalDisplayView: MTKView {
    
    weak var guiDelegate: GUIDelegate?
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guiDelegate?.GUITouchBegan(touches, with: event)
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guiDelegate?.GUITouchMoved(touches, with: event)
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        guiDelegate?.GUITouchEnded(touches, with: event)
    }
    
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        guiDelegate?.GUITouchCancelled(touches, with: event)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        guiDelegate?.GUILayoutSubViews(rect: self.frame)
    }
    
}
