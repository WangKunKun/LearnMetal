//
//  Shader.swift
//  SwiftNode
//
//  Created by aa on 2024/1/31.
//

import Foundation
import MetalKit
//MTLFunction包装器
class Shader {
    
    enum FunctionType {
    case vertex
    case fragment
    case kernel
    }
    
    var type:FunctionType
    var function:MTLFunction
    
    init(type: FunctionType, function: MTLFunction) {
        self.type = type
        self.function = function
    }
}
