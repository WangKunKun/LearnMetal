//
//  Pipe.swift
//  SwiftNode
//
//  Created by aa on 2024/1/31.
//

import Foundation

class Pipe {
    
}
