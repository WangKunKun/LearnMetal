//
//  GUITouch.swift
//  SwiftNode
//
//  Created by aa on 2024/1/30.
//

import Foundation

class GUITouch {
    var ID:String //Class Address 存为字符串更方便是方便，但是存储空间会更大
    var point:GUIPoint
    //存储的点一定是基于window的
    init(ID: String, point: GUIPoint) {
        self.ID = ID
        self.point = point
    }
}

extension GUITouch {
    func locationInNode(_ node:GUINode?) -> GUIPoint{
        guard let node = node else {
            return .zero
        }
        var pos = node.toWindowCoordinates() //得到view的起点位于window的位置
        return self.point - pos
    }
}
