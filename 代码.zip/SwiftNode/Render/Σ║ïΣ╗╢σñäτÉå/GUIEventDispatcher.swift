//
//  GUIEventDispatcher.swift
//  SwiftNode
//
//  Created by aa on 2024/1/31.
//

import Foundation

class GUIEventDispatcher {
    
    private static let shared = GUIEventDispatcher()

    private var responderMap:[String:[GUIResponder]] = [:]
    private var touchMap:[String:GUITouch] = [:]

    private init() {} //不允许外部初始化
    
    //实际上感觉是一一对应的关系
    static func add(responder:GUIResponder, with touch:GUITouch) {
        let manager = GUIEventDispatcher.shared
        let ID = touch.ID
        var list = manager.responderMap[ID] ?? [GUIResponder]()
        list.append(responder)
        manager.touchMap[ID] = touch
        manager.responderMap[ID] = list
    }
    
    static func touch(with ID:String) -> GUITouch? {
        GUIEventDispatcher.shared.touchMap[ID]
    }
    
    static func responders(for touch:GUITouch) -> [GUIResponder] {
        GUIEventDispatcher.shared.responderMap[touch.ID] ?? []
    }
    
    static func clear(with ID:String) {
        let manager = GUIEventDispatcher.shared
        manager.responderMap.removeValue(forKey: ID)
        manager.touchMap.removeValue(forKey: ID)
    }
    
}
