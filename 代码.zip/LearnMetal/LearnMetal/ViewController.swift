//
//  ViewController.swift
//  LearnMetal
//
//  Created by aa on 2024/2/1.
//

import UIKit
import MetalKit
import StoreKit


class ViewController: UIViewController {
    
    var mtkView:MTKView!
    var sourceTexture:MTLTexture?
    var device:MTLDevice!
    var commandQueue:MTLCommandQueue?
    
    var verticesBuffer:MTLBuffer!
    var numVertices:Int = 0
    
    var startTime:CGFloat = 0
    var time:CGFloat = 0
    var timeBuffer:MTLBuffer!
    var displayLink:CADisplayLink!
    
    var renderPipe:MTLRenderPipelineState?
    
    var textureCache:CVMetalTextureCache?
    var viewPortSize:CGSize!
    
    var renderPipeLines:[MTLRenderPipelineState] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        displayLink = CADisplayLink.init(target: self, selector: #selector(updateTime))
        displayLink.add(to: RunLoop.main, forMode: .common)
        self.initMTKView()
        
        UUID.init(uuidString: "")
    }
    
    func initMTKView()  {
        device = MTLCreateSystemDefaultDevice()
        mtkView = MTKView.init(frame: self.view.bounds, device: device)
        mtkView.colorPixelFormat = .bgra8Unorm
        mtkView.delegate = self
        mtkView.framebufferOnly = false
        CVMetalTextureCacheCreate(nil, nil, self.device, nil, &textureCache);
        viewPortSize = self.mtkView.drawableSize
        self.view.addSubview(mtkView)
        self.setupRenderPipeLine()
        self.setupTexture()
        self.setupVertexBuffer()
        self.commandQueue = self.mtkView.device?.makeCommandQueue()
    }
}

extension ViewController {
    func setupTexture() {
        guard let image = UIImage(named: "mouse.jpg"),
                  let device = mtkView.device else { return }
            
        let textureDescriptor = MTLTextureDescriptor()
        textureDescriptor.pixelFormat = .rgba8Unorm // 图片的格式要和数据一致
        textureDescriptor.width = Int(image.size.width)
        textureDescriptor.height = Int(image.size.height)
        textureDescriptor.usage = .shaderRead // 原图片只需要读取
        
        sourceTexture = device.makeTexture(descriptor: textureDescriptor) // 创建纹理
        
        let region = MTLRegionMake2D(0, 0, Int(image.size.width), Int(image.size.height)) // 纹理上传的范围
        if let imageBytes = image.toByte() { // UIImage的数据需要转成二进制才能上传，且不用jpg、png的NSData
            sourceTexture?.replace(region: region,
                                   mipmapLevel: 0,
                                   withBytes: imageBytes,
                                   bytesPerRow: 4 * Int(image.size.width))
            free(imageBytes) //需要释放资源
        }
    }
    
    func setupVertexBuffer() {
        
        var vertexs:[TestVertex] = []
        vertexs.append(.init(x: 1, y: -1, z: 0, w: 1, u: 1, v: 1))
        vertexs.append(.init(x: -1, y: -1, z: 0, w: 1, u: 0, v: 1))
        vertexs.append(.init(x: -1, y: 1, z: 0, w: 1, u: 0, v: 0))
        
        vertexs.append(.init(x: 1, y: -1, z: 0, w: 1, u: 1, v: 1))
        vertexs.append(.init(x: -1, y: 1, z: 0, w: 1, u: 0, v: 0))
        vertexs.append(.init(x: 1, y: 1, z: 0, w: 1, u: 1, v: 0))
        
        self.verticesBuffer = self.device.makeBuffer(bytes: &vertexs, length: MemoryLayout<TestVertex>.stride * vertexs.count, options: .storageModeShared)
        self.numVertices = vertexs.count
        
        self.timeBuffer = device.makeBuffer(length: MemoryLayout<Uniforms>.size, options: [])
    }
    
    func setupRenderPipeLine() {
        
        let pipe = PipeLineManager.pipeLine(with: .scale, pixelFormat: mtkView.colorPixelFormat, device: mtkView.device!)
        
        
//        let lib = self.device.makeDefaultLibrary()
////        let vertextFunction = lib?.makeFunction(name: "vertexShader")
////        let fragmentFunction = lib?.makeFunction(name: "fragment_soulout")
////        let fragmentFunction = lib?.makeFunction(name: "fragment_glitch")
////        let fragmentFunction = lib?.makeFunction(name: "fragment_vertigo")
////        let fragmentFunction = lib?.makeFunction(name: "fragment_shinewhite")
////        let fragmentFunction = lib?.makeFunction(name: "fragment_shake")
//        
//        let vertextFunction = lib?.makeFunction(name: "vertex_scale")
//        let fragmentFunction = lib?.makeFunction(name: "fragment_scale")
//        
//        var desc = MTLRenderPipelineDescriptor()
//        desc.vertexFunction = vertextFunction
//        desc.fragmentFunction = fragmentFunction
//        desc.colorAttachments[0].pixelFormat = mtkView.colorPixelFormat
//        var reflection:MTLAutoreleasedRenderPipelineReflection?
//        if let pipe = try? self.mtkView.device?.makeRenderPipelineState(descriptor: desc, options: MTLPipelineOption.bufferTypeInfo, reflection: &reflection) {
//            self.renderPipe = pipe
//        }
    }
}

extension ViewController {
    
    func render() {
        var commandBuffer = self.commandQueue?.makeCommandBuffer()
        var renderPassDescriptor = self.mtkView.currentRenderPassDescriptor
        guard let commandBuffer = commandBuffer, let pass = renderPassDescriptor else {
            return
        }
        //背景色
        pass.colorAttachments[0].clearColor = MTLClearColor(red: 0, green: 0.5, blue: 0.5, alpha: 0.5)
        var encoder = commandBuffer.makeRenderCommandEncoder(descriptor: pass)
        let this = PipeLineManager.pipeLine(with: .scale, pixelFormat: mtkView.colorPixelFormat, device: mtkView.device!)
        guard let encoder = encoder, let pipe = this.pipeLineState else {
            return
        }
        
        this.vertextsBuffer = self.verticesBuffer
        this.vertextBuffers.append(self.timeBuffer)
        this.fragementTextures.append(self.sourceTexture!)
        this.makeRender(with: encoder)
//        encoder.setRenderPipelineState(pipe)
//        encoder.setVertexBuffer(self.verticesBuffer, offset: 0, index: 0)
//        encoder.setVertexBuffer(self.timeBuffer, offset: 0, index: 1)
//        encoder.setFragmentTexture(self.sourceTexture, index: 0)
//        encoder.setFragmentBuffer(self.timeBuffer, offset: 0, index: 0)
//        encoder.drawPrimitives(type: MTLPrimitiveType.triangle, vertexStart: 0, vertexCount: self.numVertices)
        encoder.endEncoding()
        commandBuffer.present(self.mtkView.currentDrawable!)
        commandBuffer.commit()
    }
    
}

extension ViewController : MTKViewDelegate {
    func draw(in view: MTKView) {
        self.render()
    }
    
    func mtkView(_ view: MTKView, drawableSizeWillChange size: CGSize) {
        self.viewPortSize = size
    }
    
    
}

extension ViewController {
    @objc func updateTime() {
        if self.startTime == 0 {
            self.startTime = displayLink.timestamp
        }
        self.time = self.displayLink.timestamp - self.startTime
        var uniforms = Uniforms(time: Float(self.time))
        memcpy(self.timeBuffer.contents(), &uniforms, MemoryLayout<Uniforms>.size)
    }
}
