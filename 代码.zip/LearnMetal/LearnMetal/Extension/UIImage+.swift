//
//  UIImage+.swift
//  LearnMetal
//
//  Created by aa on 2024/2/1.
//

import Foundation
import UIKit


extension UIImage {
    
    
    func toByte() -> UnsafeMutablePointer<UInt8>? {
        
        // 1 获取图片的 CGImage
        guard let spriteImage = self.cgImage else { return nil }

        // 2 读取图片的大小
        let width = spriteImage.width
        let height = spriteImage.height

        let spriteData = calloc(width * height * 4, MemoryLayout<UInt8>.size)
        guard let data = spriteData?.assumingMemoryBound(to: UInt8.self) else { return nil } // rgba共4个byte

        guard let spriteContext = CGContext(data: data, width: width, height: height, bitsPerComponent: 8, bytesPerRow: width * 4, space: spriteImage.colorSpace!, bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return nil }

        // 3 在 CGContext 上绘图
        spriteContext.draw(spriteImage, in: CGRect(x: 0, y: 0, width: width, height: height))

        return data
    }
    
}
