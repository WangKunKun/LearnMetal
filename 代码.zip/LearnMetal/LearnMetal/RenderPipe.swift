//
//  RenderPipe.swift
//  LearnMetal
//
//  Created by aa on 2024/2/2.
//

import Foundation
import MetalKit

typealias RenderVertex = TestVertex

protocol RenderPipeProtocol {
    
    var vertextFunctionName:String {get}
    var fragementFunctionName:String {get}
    var pipeLineState:MTLRenderPipelineState? {get set}
    var vertextsBuffer:MTLBuffer? {get set}
    var vertextTextures:[MTLTexture] {get set}
    var vertextBuffers:[MTLBuffer] {get set}
    var fragementBuffers:[MTLBuffer] {get set}
    var fragementTextures:[MTLTexture] {get set}
    var portSize:CGSize {get set}
    var viewPortSize:MTLViewport {get}
    //就传这个来处理，因为可能一次渲染使用多个管道
    func makeRender(with encoder:MTLRenderCommandEncoder)
    init(with device:MTLDevice, pixelFormat:MTLPixelFormat)
}

//class RenderPipe : RenderPipeProtocol {
//    var vertextFunctionName: String
//    
//    var fragementFunctionName: String
//    
//    var pipeLineState: MTLRenderPipelineState?
//    
//    var textureBuffs: [MTLBuffer]
//    
//    var vertextBuffs: [MTLBuffer]
//    
//    var fragementBuffs: [MTLBuffer]
//    
//    var portSize: CGSize
//    
//    func makeRender(with encoder: MTLRenderCommandEncoder) {
//        <#code#>
//    }
//    
//    required init(with device: MTLDevice, pixelFormat: MTLPixelFormat) {
//        <#code#>
//    }
//    
//    
//}

class RenderPipe {
    var vertextTextures: [MTLTexture] = []
    
    var fragementTextures: [MTLTexture] = []
    
    var vertextsBuffer: MTLBuffer? //顶点buffer
    
    var vertextFunctionName: String {
        return ""
    }
    
    var fragementFunctionName: String {
        return ""
    }
    
    var pipeLineState: MTLRenderPipelineState?
    
    
    var vertextBuffers: [MTLBuffer] = []
    
    var fragementBuffers: [MTLBuffer] = []
    
    var portSize: CGSize = UIScreen.main.bounds.size
    
    var viewPortSize: MTLViewport {
        .init(originX: 0, originY: 0, width: portSize.width, height: portSize.height, znear: 0, zfar: 0)
    }
    
    func makeRender(with encoder: MTLRenderCommandEncoder) {
        guard let pipeLine = pipeLineState else {
            return
        }
        encoder.setViewport(self.viewPortSize)
        
        encoder.setRenderPipelineState(pipeLine)
        var startIndex = 0
        if let buffer = vertextsBuffer {
            encoder.setVertexBuffer(buffer, offset: 0, index: startIndex)
            startIndex += 1

        }
        for (index,value) in vertextBuffers.enumerated() {
            encoder.setVertexBuffer(value, offset: 0, index: startIndex + index)
        }
        
        for (index,value) in vertextTextures.enumerated() {
            encoder.setVertexTexture(value, index: index)
        }
        
        for (index,value) in fragementBuffers.enumerated() {
            encoder.setFragmentBuffer(value, offset: 0, index: index)
        }
        
        for (index,value) in fragementTextures.enumerated() {
            encoder.setFragmentTexture(value, index: index)
        }
        let count = (self.vertextsBuffer?.contents() as? [RenderVertex])?.count ?? 0
        encoder.drawPrimitives(type: MTLPrimitiveType.triangle, vertexStart: 0, vertexCount: count)
        self.clear()
    }
    
    func clear() {
        self.vertextsBuffer = nil
        self.vertextBuffers.removeAll()
        self.vertextTextures.removeAll()
        self.fragementBuffers.removeAll()
        self.fragementTextures.removeAll()
    }
    
    required init(with device: MTLDevice, pixelFormat: MTLPixelFormat) {
        let lib = device.makeDefaultLibrary()
        let vertextFunction = lib?.makeFunction(name: vertextFunctionName)
        let fragmentFunction = lib?.makeFunction(name: fragementFunctionName)
        var desc = MTLRenderPipelineDescriptor()
        desc.vertexFunction = vertextFunction
        desc.fragmentFunction = fragmentFunction
        desc.colorAttachments[0].pixelFormat = pixelFormat
        if let pipe = try? device.makeRenderPipelineState(descriptor: desc, options: MTLPipelineOption.bufferTypeInfo, reflection: nil) {
            pipeLineState = pipe
        }
    }
    

}

class ScaleRenderPipe : RenderPipe {
 
    override var vertextFunctionName: String {
        return "vertex_scale"
    }
    
    override var fragementFunctionName: String {
        return "fragment_scale"
    }
        
}
