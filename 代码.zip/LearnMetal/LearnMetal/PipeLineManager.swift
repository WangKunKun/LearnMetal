//
//  PipeLineManager.swift
//  LearnMetal
//
//  Created by aa on 2024/2/2.
//

import Foundation
import MetalKit

enum MetalEffect {
case normal
case vertigo
case glitch
case shineWhite
case shake
case soulOut
case scale
}

//值处理了渲染管道
class PipeLineManager {
    
    private static let shard = PipeLineManager()
    
    var pipeLineMap:[MetalEffect:RenderPipe] = [:]
    
    private init() {
        
    }
    
    static func pipeLine(with type:MetalEffect, pixelFormat:MTLPixelFormat, device:MTLDevice) -> RenderPipe {
        if let pipe = shard.pipeLineMap[type] {
            return pipe
        }
        return self.createPipeLine(with: type, pixelFormat: pixelFormat, device: device)
    }
    
    private static func createPipeLine(with type:MetalEffect, pixelFormat:MTLPixelFormat, device:MTLDevice) -> RenderPipe {
        
        var pipe = ScaleRenderPipe.init(with: device, pixelFormat: pixelFormat)
        shard.pipeLineMap[type] = pipe
        return pipe

    }
    
    
}
