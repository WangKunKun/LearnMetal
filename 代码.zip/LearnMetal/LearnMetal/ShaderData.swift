//
//  ShaderData.swift
//  LearnMetal
//
//  Created by aa on 2024/2/1.
//

import Foundation
import simd


/*
 顶点结构体
 postion 为坐标 x y z w
 x y z 为三维空间坐标
 w 为 齐次坐标系的标志
 在齐次坐标系中三维空间点会被表示为 x y z w，这种表示方法主要用于图形变换和投影计算
 
 textureCoordinate 为纹理坐标 u v，u 水平坐标 v 垂直坐标。 0,0 表示坐下 1,1 表示右上
 */
@frozen
public struct TestVertex {
    var position:vector_float4
    var textureCoordinate:vector_float2
    
    init(x:Float, y:Float, z:Float, w:Float, u:Float, v:Float) {
        self.position = vector_float4(x: x, y: y, z: z, w: w)
        self.textureCoordinate = vector_float2(x: u, y: v)
    }
}

@frozen
public struct Uniforms {
    var time:Float
}

